package com.fujitsu.loginAndRegister.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDetailsDao {
public ResultSet getDetails() {
String url="jdbc:mysql://localhost:3306/usecase?autoReconnect=true&useSSL=false";
String db_username="root";
String db_password="india@123";
		
Connection conn;
PreparedStatement pstmt;
String sql="select * from user";
try {
Class.forName("com.mysql.jdbc.Driver");
conn=DriverManager.getConnection(url,db_username,db_password);
pstmt= conn.prepareStatement(sql);
ResultSet rs=pstmt.executeQuery();
return rs;
} catch (Exception e) {
e.printStackTrace();
}
return null;		
}

}
